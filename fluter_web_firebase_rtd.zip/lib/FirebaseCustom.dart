import 'package:firebase/firebase.dart' as fb;
import 'package:firebase/firebase.dart';

//Replace These Values With Yours
class FirebaseHelper  {
  static fb.Database initDatabase() {
    try {
      if (fb.apps.isEmpty) {
        fb.initializeApp(
            apiKey: "AIzaSyA3Snj7pU2yNGu13wD4b2it6zi1sYmOuHg",
            authDomain: "crud-firebase-d783b.firebaseapp.com",
            databaseURL: "https://crud-firebase-d783b-default-rtdb.firebaseio.com",
            projectId: "crud-firebase-d783b",
            storageBucket: "crud-firebase-d783b.appspot.com",
            messagingSenderId: "134089408841",
            appId: "1:134089408841:web:c8fbbd08427a951a341a98"
        );
      }
    } on fb.FirebaseJsNotLoadedException catch (e) {
      print(e);
    }
    return fb.database();
  }
}

class Fire{
  static fb.Database database = FirebaseHelper.initDatabase();
}


Future<String> getOnce(fb.DatabaseReference adsRef) async {
  String aux;
  await adsRef.once('value').then((value) => {aux = value.snapshot.val()});
  return aux;
}

Future<List> getList(fb.DatabaseReference adsRef) async {
  List list = [""];
  await adsRef.once('value').then((value) => {
    list = result(value.snapshot, list)
  });
  return list;
}

List result(DataSnapshot dp,List list){
  list.clear();
  dp.forEach((v) {
    list.add(v);
  });
  return list;
}
import 'package:firebase/firebase.dart';
import 'package:firebase_db_web_unofficial/firebasedbwebunofficial.dart';
import 'produtos.dart';
import 'FirebaseCustom.dart';


class FirebaseDB {
  //Criando um singleton da classe (usar a mesma instância para várias operações)
  static FirebaseDB firebaseDbInstance = FirebaseDB();
  //Nó (child) onde colocaremos nosso cadastros
  String path = "produtos";

//Inserir dados
  void setValue(Produto prod) {
    //Inserindo o valor recebido no parâmetro "produto"
    //dentro do child "produtos" (definido no atributo "path" desta classe)
    FirebaseDatabaseWeb.instance.reference().child(path)
        .child(prod.id).child("id").set(prod.id);

    //Inserindo o valor recebido no parâmetro "produto"
    //dentro do child "produtos" (definido no atributo "path" desta classe)
    FirebaseDatabaseWeb.instance.reference()
        .child(path).child(prod.id).child("produto").set(prod.produto);

    //Inserindo o valor recebido no parâmetro "preco"
    //dentro do child "produtos" (definido no atributo "path" desta classe)
    FirebaseDatabaseWeb.instance.reference()
        .child(path).child(prod.id).child("preco").set(prod.preco);

    //Inserindo o valor recebido no parâmetro "qtde"
    //dentro do child "produtos" (definido no atributo "path" desta classe)
    FirebaseDatabaseWeb.instance.reference()
        .child(path).child(prod.id).child("qtde").set(prod.qtde);

    if(FirebaseDatabaseWeb.instance.reference().child(path)
        .child(prod.id).key == prod.id){
      print("Produto cadastrado com sucesso!");
    } else {
      print("Produto não cadastrado...");
    }
  }

//Pegar dados (ler)
  Future<List> getValueObject() async {
    //Capturado a referência (nó) principal
    //(neste caso, o nó "produtos", definido na variável "path")
    DatabaseReference dataRef = Fire.database.ref(path);
    //"data" recebe uma lista com todos os sub-nós de produtos.
    //getList é um método que está no arquivo FirebaseCustom.dart
    List data = await getList(dataRef);
    //Laço de repetição para ler todos os dados da lista "data"
    for(int i=0; i<data.length; i++) {
      //dadoAtual (DataSnapshot) receberá o valor
      //de "data" no índice correspondente
      DataSnapshot dadoAtual = data[i];
      //Convertendo dadoAtual para json, e depois para objeto Produto
      Produto prod = Produto.fromJson(dadoAtual.toJson());
      //print(prod);
    }
    return data;
  }

//Removendo um dado do banco de dados
  void deleteValue(String id) {
    FirebaseDatabaseWeb.instance.reference()
        .child(path)
        .child(id)
        .remove();
  }
}
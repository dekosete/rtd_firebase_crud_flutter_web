import 'package:flutter/material.dart';
import 'produtos.dart';
import 'firebase_db.dart';
import 'listadados.dart';

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key}) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  //Controladores dos TextFields
  TextEditingController controllerProduto = TextEditingController();
  TextEditingController controllerPreco = TextEditingController();
  TextEditingController controllerQtde = TextEditingController();

  //Função que joga para os campos de texto os valores editáveis
  void editarDados(){
    if(Produto.produtoEditar != null) {
      controllerProduto.text = Produto.produtoEditar.produto;
      controllerPreco.text = Produto.produtoEditar.preco;
      controllerQtde.text = Produto.produtoEditar.qtde;
    }
  }

  //Método que cria o objeto que será gravado no banco de dados.
  void _gravarDados(){
    //Se for recebido de um objeto editável, chamará o construtor com id
    if(Produto.produtoEditar != null){
      Produto prod = Produto.editar(
          Produto.produtoEditar.id,
          controllerProduto.text,
          controllerPreco.text,
          controllerQtde.text
      );
      FirebaseDB.firebaseDbInstance.setValue(prod);
      Produto.produtoEditar = null;
      //Senão, se for recebido um objeto novo, chamará o construtor sem id
    } else {
      Produto prod = Produto(
          controllerProduto.text,
          controllerPreco.text,
          controllerQtde.text
      );
      //Método setValue da instância da classe FirebaseDb.
      FirebaseDB.firebaseDbInstance.setValue(prod);
    }

    //Limpa os dados após salvar.
    controllerProduto.clear();
    controllerPreco.clear();
    controllerQtde.clear();
  }

  //initState para executar o método editarDados toda a vez que
  //a tela for aberta.
  @override
  void initState() {
    editarDados();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          TextFormField(
            decoration: InputDecoration(
              //Habilita a borda sem estar focada
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10)
              ),
              //Habilita a borda quando o campo está em foco
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: Colors.blue)
              ),
              labelText: "Produto"
            ),
            controller: controllerProduto,
          ),
          TextFormField(
              decoration: InputDecoration(
                  labelText: "Preço"
              ),
            controller: controllerPreco
          ),
          TextFormField(
              decoration: InputDecoration(
                  labelText: "Quantidade"
              ),
            controller: controllerQtde
          ),
          ElevatedButton(
            child: Text("Gravar dados"),
            onPressed: _gravarDados
          ),
          ElevatedButton(
              child: Text("Listar dados"),
              onPressed: (){
                //Vai para a tela de listagem de dados
                Navigator.push(context, MaterialPageRoute(builder: (context) => MyListData()));
              }
          )
        ],
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'homepage.dart';
import 'FirebaseCustom.dart';

void main() {
  //Usando a classe de conexão do arquivo FirebaseCustom.dart
  FirebaseHelper.initDatabase();
  runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MyHomePage()
  ));
}

# flutterweb firebase Realtime Database

A demo Flutter Web Project to Work With Firebase Realtime Database,
To use This Project, make sure to replace the Values of your Firebase Web Project in
web/Index.html and lib/FirebaseCustom.dart 

